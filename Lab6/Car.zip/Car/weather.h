

enum Weather {Sunny, Rain, Snow};
