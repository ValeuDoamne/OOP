#include <iostream>
#include "Car.h"

class bembeu : public Car
{
public:
	bembeu();
	void Print();
};
