#include <iostream>
#include "Car.h"

class Mercedes : public Car
{
public:
	Mercedes();
	void Print();
};
