#include <iostream>
#include "Car.h"

class Cazan : public Car
{
public:
	Cazan();
	void Print();
};
