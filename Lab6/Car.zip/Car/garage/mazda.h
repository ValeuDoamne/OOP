#include <iostream>
#include "Car.h"

class Mazda : public Car
{
public:
	Mazda();
	void Print();
};
