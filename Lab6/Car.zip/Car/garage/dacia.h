#include <iostream>
#include "Car.h"

class Dacia : public Car
{
public:
	Dacia();
	void Print();
};
