#include <iostream>
#include "Car.h"

class Ford : public Car
{
public:
	Ford();
	void Print();
};
