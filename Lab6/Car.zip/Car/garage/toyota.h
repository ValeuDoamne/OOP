#include <iostream>
#include "Car.h"

class Toyota : public Car
{
public:
	Toyota();
	void Print();
};
